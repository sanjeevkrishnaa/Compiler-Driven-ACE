from pathlib import Path
import sys,json,subprocess,csv
from concurrent.futures import ThreadPoolExecutor,as_completed
root=Path.cwd();sys.path.insert(0,str(root/'tools/routing_research'))
from heavy_routing import build
study=root/'output/five-workload-c8-2026-11-03'
workloads=('qft','qpeexact','qaoa','draper_qft_adder','quantum_volume')
manifest=json.loads((study/'inputs/study.json').read_text());assert manifest['status']=='complete',manifest.get('errors')
build(study,study/'inputs',('xy','history'),workloads,capacity=8)
jobs=[]
for workload in workloads:
 for route in ('xy','history'):
  dest=study/'simulation'/workload/route;dest.mkdir(parents=True,exist_ok=True)
  cmd=[sys.executable,'-B','run_trace_comparison.py','--trace',str(study/'traces'/workload/'seed_42'/route/'requests.txt'),
       '--config','config/final_config/grid_4x4_ace_3.json','--strategies','on-demand,dynamic','--seeds','60',
       '--total-memories','8','--compiler-memories','8','--generation-capacity','8','--planner-lead-layers','2',
       '--dynamic-lookahead-layers','8','--coherence-time-layers','10','--all-chain-hops','--no-congestion-threshold',
       '--scheduler','per-qubit','--admission','event','--admission-priority','ready-first',
       '--compiler-pair-consumption','handoff','--compiler-reservation-ms','50','--pregeneration-buffer-ms','0',
       '--dynamic-layer-basis','logical','--empty-layer-gap-ms','5','--layer-activation-order','execution-first',
       '--record-chain-coverage','--stop-after-workload','--audit-events','--output',str(dest)]
  jobs.append((workload,route,dest,cmd))
def run(job):
 workload,route,dest,cmd=job
 if (dest/'summary.csv').exists():
  assert json.loads((dest/'command.json').read_text())==cmd
 else:
  (dest/'command.json').write_text(json.dumps(cmd,indent=2))
  with (dest/'run.log').open('w') as log:subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 rs=list(csv.DictReader((dest/'summary.csv').open()))
 for r in rs:
  audit=json.loads((dest/f"audit_{r['strategy']}_60.json").read_text());assert not audit['violations'] and float(r['completion_rate'])==1
 print(workload,route,[(r['strategy'],r['request_latency_mean_ms']) for r in rs],flush=True)
 return [dict(workload=workload,algorithm=route,**r) for r in rs]
rows=[]
with ThreadPoolExecutor(max_workers=2) as pool:
 for f in as_completed([pool.submit(run,j) for j in jobs]):rows.extend(f.result())
with (study/'all_seeds.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
