from pathlib import Path
import json,subprocess,sys
from concurrent.futures import ThreadPoolExecutor,as_completed
root=Path.cwd();old=root/'output/greedy-xy-2026-10-30/simulation/qaoa/seed_42/history/command.json'
base=json.loads(old.read_text());base[0]=sys.executable
out=root/'output/active-layer-qaoa-2026-11-02';out.mkdir(exist_ok=True)
variants={'old-logical-5ms':('logical','5'),'logical-1us':('logical','0.001'),'active-5ms':('active','5'),'active-1us':('active','0.001')}
def run(item):
 name,(basis,gap)=item;dest=out/name;dest.mkdir(exist_ok=True)
 cmd=base.copy();cmd[cmd.index('--seeds')+1]='60';cmd[cmd.index('--output')+1]=str(dest)
 cmd+=['--dynamic-layer-basis',basis,'--empty-layer-gap-ms',gap]
 (dest/'command.json').write_text(json.dumps(cmd,indent=2))
 with (dest/'run.log').open('w') as log:subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:
 for f in as_completed([pool.submit(run,v) for v in variants.items()]):f.result()
