# Multicore congestion study

Architecture: 4x4, 128 physical slots, 4 communication slots/core.

| Workload | Seed | Active layers | Hops | Overloaded layers | % active | Peak demand |
|---|---:|---:|---:|---:|---:|---:|
| bmw_quark_cardinality | 42 | 90 | 144 | 0 | 0.00% | 2 |
| bmw_quark_cardinality | 43 | 90 | 144 | 0 | 0.00% | 2 |
| bmw_quark_cardinality | 44 | 90 | 144 | 0 | 0.00% | 2 |
| qft | 42 | 112 | 2510 | 69 | 61.61% | 24 |
| qft | 43 | 112 | 2510 | 73 | 65.18% | 22 |
| qft | 44 | 112 | 2510 | 77 | 68.75% | 24 |
| draper_qft_adder | 42 | 138 | 1310 | 54 | 39.13% | 10 |
| draper_qft_adder | 43 | 138 | 1310 | 54 | 39.13% | 10 |
| draper_qft_adder | 44 | 138 | 1310 | 63 | 45.65% | 11 |
| bv | 42 | 16 | 25 | 0 | 0.00% | 2 |
| bv | 43 | 16 | 25 | 0 | 0.00% | 2 |
| bv | 44 | 16 | 25 | 0 | 0.00% | 2 |
| qaoa | 42 | 163 | 3068 | 122 | 74.85% | 18 |
| qaoa | 43 | 163 | 3068 | 114 | 69.94% | 18 |
| qaoa | 44 | 163 | 3068 | 114 | 69.94% | 18 |
| ghz | 42 | 15 | 24 | 0 | 0.00% | 2 |
| ghz | 43 | 15 | 24 | 0 | 0.00% | 2 |
| ghz | 44 | 15 | 24 | 0 | 0.00% | 2 |
| cdkm_ripple_carry_adder | 42 | 157 | 456 | 1 | 0.64% | 9 |
| cdkm_ripple_carry_adder | 43 | 157 | 456 | 1 | 0.64% | 9 |
| cdkm_ripple_carry_adder | 44 | 157 | 456 | 1 | 0.64% | 7 |
| vqe_real_amp | 42 | 22 | 104 | 1 | 4.55% | 5 |
| vqe_real_amp | 43 | 22 | 104 | 2 | 9.09% | 5 |
| vqe_real_amp | 44 | 22 | 104 | 1 | 4.55% | 5 |
| graphstate | 42 | 6 | 76 | 2 | 33.33% | 11 |
| graphstate | 43 | 6 | 76 | 2 | 33.33% | 9 |
| graphstate | 44 | 6 | 76 | 2 | 33.33% | 13 |
| randomcircuit | 42 | 2296 | 11688 | 194 | 8.45% | 11 |
| randomcircuit | 43 | 2296 | 11688 | 173 | 7.53% | 12 |
| randomcircuit | 44 | 2296 | 11688 | 184 | 8.01% | 11 |

Overload uses the physical communication bank. Layer demand is not simultaneous occupancy. Scheduling estimates are not measured physical latency.

- [bmw_quark_cardinality seed 42](bmw_quark_cardinality/seed_42/report.html)
- [bmw_quark_cardinality seed 43](bmw_quark_cardinality/seed_43/report.html)
- [bmw_quark_cardinality seed 44](bmw_quark_cardinality/seed_44/report.html)
- [qft seed 42](qft/seed_42/report.html)
- [qft seed 43](qft/seed_43/report.html)
- [qft seed 44](qft/seed_44/report.html)
- [draper_qft_adder seed 42](draper_qft_adder/seed_42/report.html)
- [draper_qft_adder seed 43](draper_qft_adder/seed_43/report.html)
- [draper_qft_adder seed 44](draper_qft_adder/seed_44/report.html)
- [bv seed 42](bv/seed_42/report.html)
- [bv seed 43](bv/seed_43/report.html)
- [bv seed 44](bv/seed_44/report.html)
- [qaoa seed 42](qaoa/seed_42/report.html)
- [qaoa seed 43](qaoa/seed_43/report.html)
- [qaoa seed 44](qaoa/seed_44/report.html)
- [ghz seed 42](ghz/seed_42/report.html)
- [ghz seed 43](ghz/seed_43/report.html)
- [ghz seed 44](ghz/seed_44/report.html)
- [cdkm_ripple_carry_adder seed 42](cdkm_ripple_carry_adder/seed_42/report.html)
- [cdkm_ripple_carry_adder seed 43](cdkm_ripple_carry_adder/seed_43/report.html)
- [cdkm_ripple_carry_adder seed 44](cdkm_ripple_carry_adder/seed_44/report.html)
- [vqe_real_amp seed 42](vqe_real_amp/seed_42/report.html)
- [vqe_real_amp seed 43](vqe_real_amp/seed_43/report.html)
- [vqe_real_amp seed 44](vqe_real_amp/seed_44/report.html)
- [graphstate seed 42](graphstate/seed_42/report.html)
- [graphstate seed 43](graphstate/seed_43/report.html)
- [graphstate seed 44](graphstate/seed_44/report.html)
- [randomcircuit seed 42](randomcircuit/seed_42/report.html)
- [randomcircuit seed 43](randomcircuit/seed_43/report.html)
- [randomcircuit seed 44](randomcircuit/seed_44/report.html)
