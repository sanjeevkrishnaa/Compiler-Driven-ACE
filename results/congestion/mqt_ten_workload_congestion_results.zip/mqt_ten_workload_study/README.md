# Ten-workload congestion study

Open **START_HERE.html** after extracting this ZIP. All links and images are local.

## Architecture and scope

- 4x4 mesh, 128 TOTAL physical slots, four communication memories/core.
- Per core: three initially occupied data slots, one spare data slot, four communication slots.
- 48 logical circuit qubits; dynamic preparation, three compiler slots plus one fallback/adoption slot.
- HQA qubit mapping, OEE initial placement, mapper reliability range [0.1, 1.0].
- Mapping/hardware seeds 42, 43, 44; fixed circuit seed 42.
- No physical ACE simulation. Timing outputs are abstract batch/buffer components, not measured congestion delay.
- MQT randomcircuit keeps its upstream internal generator seed 10; the circuit is identical across mapping seeds.

## Workloads

BMW is bmw_quark_cardinality, not the separate BMW copula benchmark. Draper is draper_qft_adder. The complete ten-workload list is in study.json and aggregate_workloads.csv. Five controls/contrasts add GHZ, CDKM/Cuccaro, Real-Amplitudes VQE, graph state and random circuits.

## Underlying data

Every workload/seed folder preserves the normalized circuit, initial and per-layer qubit mapping, validated hop trace, per-core/per-layer/per-link CSVs, dynamic preparation schedule, hotspot heatmap, report and provenance manifest. No raw trial artifacts were removed for packaging.

- aggregate_workloads.csv: mean, range and sample SD across mapping seeds.
- aggregate_core_hotspots.csv: each workload/core aggregated across seeds.
- all_trials_cores.csv: one row per workload/seed/core.
- all_trials_layers.csv: one row per workload/seed/layer, including demand at every core.
- all_trials_edges.csv: per-link traffic, active layers and peak layer demand.
- study.json: exact command settings, versions, pipeline/mapper source hashes and available Git commit IDs.
- SHA256SUMS.csv: checksums for all packaged files except the checksum list itself.
- validation.json: mapping/trace/capacity/accounting audit.

## Reproduce after extracting

Python 3.11+:

```powershell
python -m pip install -r pipeline/requirements.txt
python pipeline/run_study.py --mapper-dir mapper_source --workloads bmw_quark_cardinality qft draper_qft_adder bv qaoa ghz cdkm_ripple_carry_adder vqe_real_amp graphstate randomcircuit --seeds 42 43 44 --circuit-seed 42 --output rerun
```

The supplied mapper's Python source snapshot is included under mapper_source/qmap. MQT Bench is installed as a dependency; the versions and actual circuit/factory hashes used are recorded. These files retain their original copyright/license notices. Consult pipeline/README.md for configuration and optional physical simulation.
