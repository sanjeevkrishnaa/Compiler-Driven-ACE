from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,sys,subprocess,csv
root=Path.cwd();out=root/'output/qaoa-cgp-acgp-10ns-2026-11-03';out.mkdir(exist_ok=True)
base=json.loads((root/'output/qaoa-preparation-policy-2026-11-03/quota6/command.json').read_text())
def run(strategy):
 dest=out/strategy;dest.mkdir(exist_ok=True);cmd=base.copy();cmd[0]=sys.executable
 cmd[cmd.index('--strategies')+1]=strategy;cmd[cmd.index('--output')+1]=str(dest)
 cmd+=['--autonomous-cache-follows-compiler-memories']
 (dest/'command.json').write_text(json.dumps(cmd,indent=2))
 with (dest/'run.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 row=next(csv.DictReader((dest/'summary.csv').open()))
 audit=json.loads((dest/f'audit_{strategy}_60.json').read_text())
 assert not audit['violations'] and float(row['completion_rate'])==1
 print(strategy,row['request_latency_mean_ms'],flush=True)
 return row
with ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run,('continuous','adaptive-continuous')))
with (out/'all_seeds.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
