from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,subprocess,sys,csv

root=Path.cwd()
study=root/'output/qaoa-history-active16-10ns-2026-11-03'
study.mkdir(parents=True,exist_ok=True)
sources={
 'm8':root/'output/five-workload-c8-2026-11-03/simulation/qaoa/history',
}
def run(item):
 name,baseline=item
 dest=study/name
 dest.mkdir(exist_ok=True)
 cmd=json.loads((baseline/'command.json').read_text())
 cmd[0]=sys.executable
 for flag,value in [('--strategies','dynamic'),('--dynamic-layer-basis','active'),('--empty-layer-gap-ms','0.00001'),('--dynamic-lookahead-layers','16'),('--coherence-time-layers','17'),('--output',str(dest))]:
  cmd[cmd.index(flag)+1]=value
 (dest/'command.json').write_text(json.dumps(cmd,indent=2))
 with (dest/'run.log').open('w') as log:
  subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 row=next(csv.DictReader((dest/'summary.csv').open()))
 audit=json.loads((dest/'audit_dynamic_60.json').read_text())
 assert float(row['completion_rate'])==1 and not audit['violations']
 print(name,json.dumps(row),flush=True)
 return dict(memory=name,baseline=str(baseline),folder=str(dest),**row)
with ThreadPoolExecutor(max_workers=2) as pool:
 rows=list(pool.map(run,sources.items()))
with (study/'all_seeds.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
