from pathlib import Path
import json,subprocess,sys
from concurrent.futures import ThreadPoolExecutor,as_completed
root=Path.cwd();base=root/'output/greedy-xy-2026-10-30';out=root/'output/history-xy-m3-c3-seed60-2026-10-30';out.mkdir(exist_ok=True)
jobs=[]
for w in ['qft','qaoa','bv']:
 for route in ['xy','history']:
  old=base/f'simulation/{w}/seed_42/{route}'
  cmd=json.loads((old/'command.json').read_text())
  cmd[0]=sys.executable
  dest=out/w/route;dest.mkdir(parents=True,exist_ok=True)
  for flag,value in [('--total-memories','3'),('--strategies','dynamic'),('--seeds','60'),('--compiler-memories','3'),('--generation-capacity','3'),('--output',str(dest))]:cmd[cmd.index(flag)+1]=value
  (dest/'command.json').write_text(json.dumps(cmd,indent=2));jobs.append((w,route,dest,cmd))
def run(job):
 w,route,dest,cmd=job
 with (dest/'run.log').open('w') as log:subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(w,route,'complete',flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:
 for f in as_completed([pool.submit(run,j) for j in jobs]):f.result()
