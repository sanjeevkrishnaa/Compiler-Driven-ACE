from pathlib import Path
import json,sys,subprocess,csv
from concurrent.futures import ThreadPoolExecutor,as_completed
root=Path.cwd();base=root/'output/five-workload-c8-2026-11-03';out=root/'output/unlimited-memory-2026-11-03'
reference=json.loads((out/'reference_node_seeds.json').read_text())
jobs=[(w,r) for w in ('qft','qpeexact','qaoa','draper_qft_adder','quantum_volume') for r in ('xy','history')]
def run(job):
 workload,route=job
 original=json.loads((base/'simulation'/workload/route/'command.json').read_text())
 for capacity in (256,512,1024):
  dest=out/workload/route/f'm{capacity}';dest.mkdir(parents=True,exist_ok=True)
  cmd=original.copy();cmd[0]=sys.executable
  for flag,value in [('--strategies','dynamic'),('--total-memories',str(capacity)),('--compiler-memories',str(capacity)),('--output',str(dest))]:cmd[cmd.index(flag)+1]=value
  cmd+=['--seed-reference-memories','8']
  if (dest/'summary.csv').exists():assert json.loads((dest/'command.json').read_text())==cmd
  else:
   (dest/'command.json').write_text(json.dumps(cmd,indent=2))
   with (dest/'run.log').open('w') as log:subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
  row=next(csv.DictReader((dest/'summary.csv').open()))
  audit=json.loads((dest/'audit_dynamic_60.json').read_text());assert not audit['violations'] and float(row['completion_rate'])==1
  diagnostic=json.loads((dest/'capacity_dynamic_60.json').read_text());assert diagnostic['node_seeds']==reference
  peak=max(diagnostic['peak_booked_plus_outstanding_bound_per_node'].values(),default=0)
  quota=max(diagnostic['peak_compiler_bookings_per_node'].values(),default=0)
  rejection=diagnostic['compiler_rejection_reasons']
  limited=any(rejection.get(k,0) for k in ('local_memory_quota','local_timecard','remote_memory_or_timecard'))
  if peak<capacity and quota<capacity and not limited:
   print(workload,route,'nonbinding',capacity,'bound',peak,'latency',row['request_latency_mean_ms'],flush=True)
   return dict(workload=workload,route=route,capacity=capacity,peak_bound=peak,peak_compiler=quota,folder=str(dest),**row)
  print(workload,route,'retry larger pool',capacity,peak,rejection,flush=True)
 raise RuntimeError('nonbinding capacity not established')
rows=[]
with ThreadPoolExecutor(max_workers=2) as pool:
 for f in as_completed([pool.submit(run,j) for j in jobs]):rows.append(f.result())
with (out/'all_seeds.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
