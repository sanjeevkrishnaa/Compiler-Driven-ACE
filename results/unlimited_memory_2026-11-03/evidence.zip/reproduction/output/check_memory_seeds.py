import json,tempfile
from pathlib import Path
import numpy as np
from ace.topology.router_net_topo_adaptive import RouterNetTopoAdaptive
from ace.simulation.parallel_core import seed_entity_indices
original=json.loads(Path('config/final_config/grid_4x4_ace_3.json').read_text()); maps={};names={};nodes={}
for count in [8,256]:
 config=json.loads(json.dumps(original))
 for n in config['nodes']:
  if 'memo_size' in n:n['memo_size']=count
 with tempfile.NamedTemporaryFile(mode='w',suffix='.json',delete=False) as f:json.dump(config,f);name=f.name
 try:topo=RouterNetTopoAdaptive(name)
 finally:Path(name).unlink()
 tl=topo.get_timeline();maps[count]=seed_entity_indices(tl.entities,8);names[count]=set(tl.entities)
 nodes[count]={name:int(np.random.SeedSequence([60,i]).generate_state(1)[0]) for name,i in maps[count].items() if hasattr(tl.entities[name],'set_seed')}
assert all(maps[8][name]==maps[256][name] for name in names[8])
assert nodes[8]==nodes[256]
p=Path('output/unlimited-memory-2026-11-03');p.mkdir(exist_ok=True)
(p/'reference_node_seeds.json').write_text(json.dumps(nodes[8],indent=2))
print('Reference component RNG streams preserved:',len(nodes[8]),'nodes;',len(names[8]),'reference entities')
