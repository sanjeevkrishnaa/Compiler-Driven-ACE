from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import csv,json,sys,subprocess
root=Path.cwd();out=root/'output/qft-history-three-strategies-10ns-2026-11-03';out.mkdir(exist_ok=True)
base=json.loads((root/'output/qaoa-preparation-policy-2026-11-03/demand6/command.json').read_text())
base.remove('--demand-first')
def run(strategy):
 dest=out/strategy;dest.mkdir(exist_ok=True);cmd=base.copy();cmd[0]=sys.executable
 for flag,value in [('--trace',str(root/'output/five-workload-c8-2026-11-03/traces/qft/seed_42/history/requests.txt')),('--strategies',strategy),('--output',str(dest))]:cmd[cmd.index(flag)+1]=value
 if strategy=='dynamic':cmd+=['--demand-first']
 if strategy=='adaptive-continuous':cmd+=['--autonomous-cache-follows-compiler-memories']
 (dest/'command.json').write_text(json.dumps(cmd,indent=2))
 with (dest/'run.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 row=next(csv.DictReader((dest/'summary.csv').open()))
 audit=json.loads((dest/f'audit_{strategy}_60.json').read_text())
 assert not audit['violations'] and float(row['completion_rate'])==1
 print(strategy,'latency',row['request_latency_mean_ms'],'makespan_ms',row['end_to_end_latency_ms'],flush=True)
 return row
rows=[]
with ThreadPoolExecutor(max_workers=2) as pool:
 for f in as_completed([pool.submit(run,s) for s in ('dynamic','on-demand','adaptive-continuous')]):rows.append(f.result())
with (out/'all_seeds.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
