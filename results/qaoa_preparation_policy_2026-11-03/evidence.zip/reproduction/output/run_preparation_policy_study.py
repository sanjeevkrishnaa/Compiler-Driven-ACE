from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import json,csv,subprocess,sys
root=Path.cwd();out=root/'output/qaoa-preparation-policy-2026-11-03';out.mkdir(exist_ok=True)
base=json.loads((root/'output/qaoa-history-active16-10ns-2026-11-03/m8/command.json').read_text())
jobs=[(f'quota{q}',q,[]) for q in (4,5,6,7)]
jobs += [('demand6',6,['--demand-first']),
         ('release6',6,['--demand-first','--refill-on-release','--preparation-priority','dependency']),
         ('runtime6',6,['--demand-first','--refill-on-release','--preparation-priority','dependency','--planning-mode','runtime']),
         ('odg',8,[])]
def run(job):
 name,quota,extra=job;dest=out/name;dest.mkdir(exist_ok=True)
 cmd=base.copy();cmd[0]=sys.executable
 for flag,value in [('--compiler-memories',str(quota)),('--output',str(dest)),('--strategies','on-demand' if name=='odg' else 'dynamic')]:cmd[cmd.index(flag)+1]=value
 cmd+=extra
 (dest/'command.json').write_text(json.dumps(cmd,indent=2))
 with (dest/'run.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 row=next(csv.DictReader((dest/'summary.csv').open()))
 audit=json.loads((dest/f"audit_{row['strategy']}_60.json").read_text())
 assert not audit['violations'] and float(row['completion_rate'])==1,(name,audit)
 print(name,'latency',row['request_latency_mean_ms'],'makespan_ms',row['end_to_end_latency_ms'],'readiness',row['pregenerated_success_rate'],flush=True)
 return dict(configuration=name,quota=quota,folder=str(dest),**row)
rows=[]
with ThreadPoolExecutor(max_workers=2) as pool:
 for future in as_completed([pool.submit(run,j) for j in jobs]):rows.append(future.result())
with (out/'all_seeds.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
