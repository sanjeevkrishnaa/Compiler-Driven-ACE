from pathlib import Path
import json,sys,subprocess
from concurrent.futures import ThreadPoolExecutor,as_completed
root=Path.cwd();cmd=json.loads((root/'output/active-layer-qaoa-2026-11-02/old-logical-5ms/command.json').read_text());cmd[0]=sys.executable
out=root/'output/execution-first-qaoa-2026-11-03';out.mkdir(exist_ok=True)
variants={'original':('preparation-first',False),'execution-first':('execution-first',False),'execution-first-guarded':('execution-first',True)}
def run(item):
 name,(order,guard)=item;dest=out/name;dest.mkdir(exist_ok=True);c=cmd.copy();c[c.index('--output')+1]=str(dest);c+=['--layer-activation-order',order]
 if guard:c+=['--demand-first']
 (dest/'command.json').write_text(json.dumps(c,indent=2))
 with (dest/'run.log').open('w') as f:subprocess.run(c,cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:
 for f in as_completed([pool.submit(run,x) for x in variants.items()]):f.result()
